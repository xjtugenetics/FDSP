library(testthat)
library(SNPprediction)
  
test_check("SNPprediction")
