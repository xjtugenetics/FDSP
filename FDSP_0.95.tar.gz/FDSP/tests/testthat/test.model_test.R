 library(testthat)
library(SNPprediction) 
test_that("Type of output",{
		    load("/home/cyx/project/R_packages/test1/SNPprediction/extdata/model.Rdata")
			load('/home/cyx/project/R_packages/test1/SNPprediction/extdata/dataset.Rdata')
			test_data<-dataset[[2]]
			 evaluate_data <- model_evaluate(model, test_data)
			expect_is(model_test,"list") 
			 }
  )
  
