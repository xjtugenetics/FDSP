## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  library('FDSP')
#  SNPanno<-read.csv(file.path(system.file('extdata', 'SNP_ori.csv',
#  			package="FDSP")), header=T)
#  save(SNPanno, file='example.SNPanno.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.SNPanno.Rda', package='FDSP')))
#   SNPdatafilter <- filter_features(SNPanno)
#  save(SNPdatafilter, file="example.SNPdatafilter.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='FDSP')))
#  dataset<-create_dataset(SNPdatafilter,numbercv=5)
#  train_data<-dataset[[1]]
#  test_data<-dataset[[2]]
#  save(dataset, file="example.dataset.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.dataset.Rda', package='FDSP')))
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='FDSP')))
#  train_data<-dataset[[1]]
#  model <- model_train(SNPdatafilter, train_data, method="rf", numbercv = 5)
#  save(model, file="example.model.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.model.Rda', package='FDSP')))
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='FDSP')))
#  test_data<-dataset[[2]]
#  evaluate_data <- model_evaluate(model, test_data)
#  prediction_results <- evaluate_data[[1]]
#  confusion_matrix <- evaluate_data[[2]]
#  F1_score <- evaluate_data[[3]]
#  feature_importance <- evaluate_data[[4]]
#  save(evaluate_data,  file='example.evaluate_data.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='FDSP')))
#  load(file.path(system.file('extdata', 'example.evaluate_data.Rda', package='FDSP')))
#  model_best_set<-select_features(SNPdatafilter,evaluate_data,from=10,to=100,sep=10)
#  model_best <- model_best[[1]]
#  feature_best <- model_best[[4]]
#  save( model_best_set, file='example.model_best_set.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  test <- read.csv(file.path(system.file('extdata','test.csv',header=T)))
#  load(file.path(system.file('extdata', 'example.model_best_set.Rda', package='FDSP')))
#  rownames(test) <- test[,1]
#  feature_best <- test[, feature_best ]
#  predict_test <- SNP_predict(model_best,feature_best)
#  predict_test

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  save(predict_test, file='example.predict_test.Rda')
#  write.table(as.data.frame( predict_test), file='example.results.txt', row=T, col=F, quote=F, sep="\t")

