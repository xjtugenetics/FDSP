#' Get the predictive risk SNPs
#'
#' @param Model_best input results from fuction "select_features".
#' @param Dataset SNP data with features.
#' @return Model training by train dataset and all feature.
#' @examples
#' test_cv <- model_cv(SNPdatafilter,no_cv=1, method="rf", start=100, end=900, sep=200, numbercv = 5, cores=5)
#' save(model, file='test_cv.Rdata')
#' @export
model_cv <- function(SNPdatafilter, no_cv, method="rf", start=10, end=100, sep=10, numbercv = 5, cores = 10){
	dataset<-create_dataset(SNPdatafilter,numbercv=numbercv)
	test_data <- dataset[[no_cv]]
	train_data <- do.call(rbind, dataset[setdiff(1:length(dataset),no_cv)])


	n_feature <- dim(SNPdatafilter)[2]
	feature_list <- c(rep(1,n_feature-1))
	names(feature_list) <- colnames(SNPdatafilter)[-n_feature]
	select_features_1 <- compiler::cmpfun(select_features, options=list(optimize=3))
	doMC::registerDoMC(cores = as.numeric(cores))
	feature_total <- select_features_1(train_data, test_data,feature_list,no_cv=no_cv, start=n_feature-1,end=n_feature-1, sep=0,method=method, numbercv = numbercv, cores = cores)
	feature_list <- feature_total[[1]][[1]]$importance[,1]
	names(feature_list) <- rownames(feature_total[[1]][[1]]$importance)

	#print(length(feature_list))
	doMC::registerDoMC(cores)
	feature_result <- select_features_1(train_data, test_data,feature_list, no_cv=no_cv, start=start,end=end, sep=sep, method=method, numbercv = numbercv, cores = cores)
#	print(top_feature)
	#model_best$attr <- model_attr[[1]]
	#model_best$model <- model_list[[1]]
	#model_best$f1 <- f1_score
	return(feature_result)
}


#' Select model working best.
#'
#' @param SNPdatafilter input a SNP data after filter high correlation feature.
#' @param train_data results from function 'model_evaluate'.
#' @param test_data results from function 'model_evaluate'.
#' @param feature_list a vector include features for training model.
#' @param no_cv integer, the number of fold in dataset 
#' @param start the maximum top  several feature you want to test in model.
#' @param end integer, the maximum top  several feature you want to test in model.
#' @param sep integer, number of feature to skip.
#' @param method input model type.
#' @param numbercv number of cross-validation.
#' @param cores integer, the number of parallel when running the function.
#' @return Attributes of the best working model.
#' @examples
#' model_best<-select_features(SNPdatafilter,evaluate_data,from=5,to=400,sep=20)
#' save(model_best,'model_best.Rdata')
#' @export
select_features <- function(train_data, test_data, feature_list, no_cv, start=5,end=length(feature_list),sep=5,method="rf", numbercv = 5, cores=10 ){  #Feature and model selection.
	n<-1
	message("Loding feature importance...")

	#feature_list[order(-feature_list)]
	#seq(from=1,to=length(feature_list),by=1)
	feature_evaluate_set <- list()
	top_feature_set <- list()
	num_fs <- unique(c(end,seq(from=end,to=start,by=-(sep)),start))
	model_f_attr <-  as.list(numeric(length(num_fs)))
	model_f_f1 <- as.data.frame(numeric(length(num_fs)))
	cv_name <- paste("cv",no_cv,sep="")
	colnames(model_f_f1)[1] <- cv_name

	for (i in  num_fs){
		message(paste("Selecting top", i, "important features..."))
		#seq(from=5,to=length(feature_list),by=1)
		top_feature <- as.vector(names(feature_list[order(-feature_list)][1:i]))
		test_data <- test_data[,c(top_feature,"Class")]
		train_data <- train_data[,c(top_feature,"Class")]
		#print(head(train_data))
		up_train<-caret::upSample(x=train_data[,-ncol(train_data)],y=train_data$Class)
		train_control<-caret::trainControl(method='cv',number=numbercv,allowParallel = TRUE)
		doMC::registerDoMC(cores = as.numeric(cores))
		model_f <- caret::train(Class~.,data=up_train,trControl=train_control,method=method)
		model_attr <- model_evaluate(model_f,test_data)
		model_n <- paste("feature",i,sep="")
		model_f_attr[[n]] <- model_attr$feature_importance
		names(model_f_attr)[n] <- model_n
		model_f_f1[n,1] <- model_attr[[3]]
		rownames(model_f_f1)[n] <- model_n
		#assign(paste("feature",n,sep=""), model_f$model_f1)
		#model_f_f1 <- cbind(model_f_f1,get())
		feature_list <- model_attr$feature_importance$importance[,1]
		names(feature_list) <- rownames(model_attr$feature_importance$importance)
		n=n+1
		}
#id_f <- ifelse(model_f_attr[[1]][[3]] > model_f_attr[[2]][[3]],1,2)
		model_f_best <-list()
		model_f_best$attr <- model_f_attr
		model_f_best$f1 <- model_f_f1
		names(model_f_best)[1] <- cv_name
		return(model_f_best)		
}


#' Train a model with all of input feature. This function could fits models as your selection with train dataset and returns the best performance model and features.
#'
#' @param SNPdatafilter input a SNP data after filtering high correlation feature.
#' @param model input a string specifying which model to use. This function will fit five types of model: CSimca(CSimca), radial basis function kernel(svmRadial), C5.0(C5.0) and random forest(rf) when this parameter is set as "all".
#' @param method The resampling method: \code{"boot"}, \code{"boot632"},  \code{"optimism_boot"}, \code{"boot_all"}, \code{"cv"}, \code{"repeatedcv"}, \code{"LOOCV"}, \code{"LGOCV"} (for repeated training/test splits), \code{"none"} (only fits one model to the entire training set), \code{"oob"} (only for random forest, bagged trees, bagged earth, bagged flexible discriminant analysis, or conditional tree forest models), \code{timeslice}, \code{"adaptive_cv"}, \code{"adaptive_boot"} or \code{"adaptive_LGOCV"}.
#' @param numbercv number of cross-validation.
#' @param start integer, the minimum top several feature you want to test in model.
#' @param end integer, the maximum top  several feature you want to test in model.
#' @param sep integer, number of feature to skip.
#' @param cores integer, the number of parallel when running the function.
#' @return The best working model, with the best performeed model and the most important features.
#' @examples
#' model <- model_train(SNPdatafilter, train_data, method="rf", numbercv = 5)
#' save(model, file='model.Rdata')
#' @import doMC
#' @export
model_train<-function(SNPdatafilter, model="all",method="cv", numbercv = 5, cores = 20, start=100, end=900, sep=200){  #Model training.
	train_control<-caret::trainControl(method='cv',number=numbercv)
	model_total_list<-list()
	model_total_attr <- list()
	SNPdatafilter$Class <- as.factor(SNPdatafilter$Class)
	dataset<-create_dataset(SNPdatafilter,numbercv=numbercv)

	if (model=="all"){
		n_model<-c("CSimca","svmRadial","C5.0","rf")
		#n_model<-c("CSimca",'mlpML')
		print(n_model)
		f1_feature_model <- as.list(numeric(length(n_model)))

		for (i in 1:length(n_model)){   ##four models selection
			MET=n_model[i]	
			message(paste(MET, "model training, please wait..."))
			message("Attention: This step may takes several hours.The time changes with your device.")
			feature_list <- as.list(numeric(numbercv))
			for (n in 1:numbercv){
			message(paste( "fold",n))
			doMC::registerDoMC(as.numeric(cores))
			cv_set <- model_cv(SNPdatafilter,no_cv=n, method=MET, start=start, end=end, sep=sep, numbercv = numbercv, cores = cores)
			feature_list[[n]] <- cv_set
			#print(feature_list)
			}
			f1 <- lapply(feature_list, function(x){as.data.frame(cbind(x$f1))})
			f1_total <-  as.data.frame(f1)
			f1_s <- apply(f1_total,1,mean)
			f1_feature_best <- max(f1_s)
			names(f1_feature_best)	<- names(f1_s[order(-f1_s)][1])
			#print(f1_feature_best)
			f1_feature_model[[i]] <- f1_feature_best
			names(f1_feature_model)[i] <- MET
			#print(paste("f1_feature_model",f1_feature_model))
		}
			f1_total <- f1_feature_model[order(-as.data.frame(f1_feature_model))][1]
			model_final <- as.character(names(f1_total))
			feature_final <- as.numeric(substr(as.character(names(f1_total[[1]])),8,nchar(names(f1_total[[1]]))))

			train_control<-caret::trainControl(method='cv',number=numbercv,allowParallel = TRUE)
			doMC::registerDoMC(cores)
			up_train<-caret::upSample(x=SNPdatafilter[,-ncol(SNPdatafilter)],y=SNPdatafilter$Class)
			model_f <- caret::train(Class~.,data=up_train,trControl=train_control,method=model_final)
			imp <- caret::varImp(model_f,scale=TRUE)
			feature_f <- as.vector(imp$importance[,1])
			 names(feature_f) <-  rownames(imp$importance)
			feature_f <- feature_f[order(-feature_f)][1:feature_final]
			

}else{
	MET=model
	message("Model training, please wait...")
	message("Attention: This step may takes several hours.The time changes with your device.")
	feature_list <- as.list(numeric(numbercv))
	f1_feature_model <- as.list(numeric(1))
	for (n in 1:numbercv){
		message(paste( "fold",n))
		cv_set <- model_cv(SNPdatafilter,no_cv=n, method=MET, start=start, end=end, sep=sep, numbercv = numbercv, cores = cores)
		feature_list[[n]] <- cv_set
		#print(feature_list)
		}
	f1 <- lapply(feature_list, function(x){as.data.frame(cbind(x$f1))})
	f1_total <-  as.data.frame(f1)
	f1_s <- apply(f1_total,1,mean)
	f1_feature_best <- max(f1_s)
	names(f1_feature_best)	<- names(f1_s[order(-f1_s)][1])
	#print(f1_feature_best)
	model_final <- MET
	feature_final <- as.numeric(substr(as.character(names(f1_feature_best)),8,nchar(names(f1_feature_best))))

	train_control<-caret::trainControl(method='cv',number=numbercv,allowParallel = TRUE)
	doMC::registerDoMC(cores)
	up_train<-caret::upSample(x=SNPdatafilter[,-ncol(SNPdatafilter)],y=SNPdatafilter$Class)
	model_f <- caret::train(Class~.,data=up_train,trControl=train_control,method=model_final)
	imp <- caret::varImp(model_f,scale=TRUE)
	feature_f <- as.vector(imp$importance[,1])
	names(feature_f) <-  rownames(imp$importance)
	feature_f <- feature_f[order(-feature_f)][1:feature_final]
		

	}

    SNP_negative <- rownames(SNPdatafilter[which(SNPdatafilter$Class==0),])
    SNP_positive <- rownames(SNPdatafilter[which(SNPdatafilter$Class==1),])
    score_f <- log2( ((as.matrix(apply(SNPdatafilter[, -dim(SNPdatafilter)[2]],2, function(x){sum( x[SNP_positive] ) }))) / length(SNP_positive) ) / ((as.matrix(apply(SNPanno[, -dim(SNPanno)[2]],2, function(x){sum( x[SNP_negative] ) }))) / length(SNP_negative)))
	return(list(model=model_f,feature_importance=feature_f, score_fci = score_f))
}

