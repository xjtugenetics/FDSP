## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  library('MP')
#  SNPanno<-read.csv(file.path(system.file('extdata', 'SNP_ori.csv',
#  							package="MP")), header=T)
#  			
#  rownames(SNPanno)<-SNPanno[,1]
#  SNPanno <- SNPanno[, -1]
#  save(SNPanno, file='example.SNPanno.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  data(SNPanno)
#  	 SNPdatafilter <- filter_features(SNPanno)
#  	save(SNPdatafilter, file="example.SNPdatafilter.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  data(SNPdatafilter)
#  dataset<-create_dataset(SNPdatafilter,numbercv=5)
#  no_cv <- 1
#  test_data <- dataset[[no_cv]]
#  train_data <- do.call(rbind, dataset[setdiff(1:length(dataset),no_cv)])
#  save(dataset, file="example.dataset.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  data(SNPdatafilter)
#  model <-  model_train(SNPdatafilter,method="cv", model="all", cores = 10,start=10, end=60, sep=10)
#  model_best <- model$model
#  feature_importance <- model$feature_importance
#  save(model, file="example.model.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  data(SNPdatafilter)
#  model_rf <-  model_train(SNPdatafilter,method="cv", model="rf", cores = 10,start=10, end=60, sep=10)
#  model_best <- model$model
#  feature_importance <- model$feature_importance
#  save( model_rf, file='example.model_rf.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  data(model)
#  test <- read.csv(file.path(system.file('extdata','test.csv', package='MP')),header=T)
#  rownames(test) <- test[,1]
#  test <- test[,-1]
#  predict_test <- SNP_predict(model,test)
#  save(predict_test, file='example.predict_test.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  write.table(predict_test, file='example.results.txt', row=F, col=T, quote=F, sep="\t")

