## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='MP')))
#  dataset<-create_dataset(SNPdatafilter,numbercv=5)
#  no_cv <- 1
#  test_data <- dataset[[no_cv]]
#  train_data <- do.call(rbind, dataset[setdiff(1:length(dataset),no_cv)])
#  save(dataset, file="example.dataset.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  load(file.path(system.file('extdata', 'example.SNPdatafilter.Rda', package='MP')))
#  model <- model_train(SNPdatafilter,cores = 10,start=10, end=100, sep=10)
#  save(model, file="example.model.Rda")

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  
#  save(evaluate_data,  file='example.evaluate_data.Rda')

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  test <- read.csv(file.path(system.file('extdata','test.csv',header=T)))
#  load(file.path(system.file('extdata', 'example.model_best_set.Rda', package='MP')))
#  rownames(test) <- test[,1]
#  feature_best <- test[, feature_best ]
#  predict_test <- SNP_predict(model_best,feature_best)
#  predict_test

## ----warning=FALSE, message=FALSE, tidy=TRUE, eval=FALSE-----------------
#  save(predict_test, file='example.predict_test.Rda')
#  write.table(as.data.frame( predict_test), file='example.results.txt', row=T, col=F, quote=F, sep="\t")

