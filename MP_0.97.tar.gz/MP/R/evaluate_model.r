#' Evaluated a model.
#'
#' @param model input a model from fuction "model_train".
#' @param test_data input a test dataset from "create_dataset".
#' @return Prediction results, confusion matrix, F1 score and feature importance.
#' @examples
#' model_evl <- model_evaluate(model, test_data)
#' prediction_results <- model_evl[[1]]
#' confusion_matrix <- model_evl[[2]]
#' F1_score <- model_evl[[3]]
#' feature_importance <- model_evl[[4]]
#' @export
model_evaluate<-function(model, test_data){  #Model evaluation.
predictions<-stats::predict(model, test_data)
confusionmatrix<-caret::confusionMatrix(predictions, test_data$Class, positive="1")
precision <- caret::posPredValue(predictions, test_data$Class, positive="1")
recall <- caret::sensitivity(predictions, test_data$Class, positive="1")
F1 <- (2 * precision * recall) / (precision + recall) 
imp <- caret::varImp(model,scale=TRUE)
return(list(predictions=predictions,confusion_matrix=confusionmatrix,F1_score=F1,feature_importance=imp))
}


#' Get the predictive risk SNPs
#'
#' @param Model_best input results from fuction "select_features".
#' @param Dataset SNP data with features.
#' @return Model training by train dataset and all feature.
#' @examples
#' load(file.path(system.file('extdata', 'example.model.Rda', package='MP')))
#' test <- read.csv(file.path(system.file('extdata','test.csv',header=T)))
#' rownames(test) <- test[,1]
#' predict_test <- SNP_predict(model_best,feature_best, score)
#' save(predict_test, file='example.predict_test.Rda')
#' @export
SNP_predict <- function(model, dataset, score){
	if (score != F) {
	model_best <- model$model
	feature_importance <- model$feature_importance

	predictions <- stats::predict(model_best, dataset)
	names(predictions) <- rownames(dataset)
	SNP_negative <- names(predictions[which(predictions==0)])
	SNP_positive <- names(predictions[which(predictions==1)])

	features <- as.matrix(dataset[,feature_importance])
	score_f <- features %*% score  }else {
	
	model_best <- model$model
	feature_importance <- model$feature_importance
	predictions <- stats::predict(model_best, dataset)
	names(predictions) <- rownames(dataset)
	  SNP_negative <- names(predictions[which(predictions==0)])
	 SNP_positive <- names(predictions[which(predictions==1)])

 	 score_f <- NA

	}

	return(list(predictions=predictions,score=score_f))
}


#' Calculate a parameter FCi of SNP score S
#'
#' @param SNPanno A matrix include SNP annotation and lable information. Its format is as same as SNPanno variable in 'Filter features' step.
#' @return A vector of SNP score.
#' @examples
#' load(file.path(system.file('extdata', 'example.SNPanno.Rda', package='MP')))
#' score <- SNP_score(SNPanno)
#' save(predict_test, file='example.score.Rda')
#' @export
SNP_score <- function(SNPanno){

SNP_negative <- rownames(SNPanno[which(SNPanno$Class==0),])
SNP_positive <- rownames(SNPanno[which(SNPanno$Class==1),])
score_f <- log2( ((as.matrix(apply(SNPanno[, -dim(SNPanno)[2]],2, function(x){sum( x[SNP_positive] ) }))) /  length(SNP_positive) ) / ((as.matrix(apply(SNPanno[, -dim(SNPanno)[2]],2, function(x){sum( x[SNP_negative] ) }))) /  length(SNP_negative))  )
return(score_f)
}
