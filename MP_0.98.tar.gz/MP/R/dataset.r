#' Filtering high correlation features.
#'
#' @param SNPdata SNP dataset loaded from a file. The first column is SNP name list. The last column is the status of SNP (did it have identified as a label SNP? Set "1" when the answer is "yes".) The colname of last column MUST be "Class".
#' @param Correlation input the coefficient correlation, default is 0.70.
#' @return SNP dataset without high correlation feature.
#' @examples
#' SNPdatafilter <- filter_features(SNPdata)
#' save(SNPdatafilter, file='SNPdatafilter.Rdata')
#' @export
filter_features <- function(SNPdata, correlation=0.70){   #Correlation calculation, and hight correlation filtering.

	rownames(SNPdata) <- rownames(SNPdata)
	Class <- SNPdata[,length(colnames(SNPdata))]
    SNPdata <- SNPdata[,-length(colnames(SNPdata))]
    SNPdata_scale <- scale(SNPdata, center=T, scale=T)
	cor_SNPdata <- cor(SNPdata_scale)
	cor_SNPdata[is.na(cor_SNPdata)] <- 0
	highlyCor <- caret::findCorrelation(cor_SNPdata, correlation)  #Correlation calculation.i
	if (length(highlyCor) == 0){
	fea_filter <- SNPdata       #Remove high correlation.
	}else{
	fea_filter <- SNPdata[,-highlyCor]
	}

	fea_filter <- as.data.frame(cbind(fea_filter, Class))
	fea_filter[is.na(fea_filter)] <- 0
	return(fea_filter)
}

#' Devide dataset into train dataset and test dataset.
#'
#' @param SNPdatafilter input a SNP data after filter high correlation feature. 
#' @param numbercv cross-validation number.
#' @return A list contains n-fold dataset ( n equals to numbercv). Train dataset and test dataset in a list.
#' @examples
#' dataset <- create_dataset(SNPdatafilter)
#' train_data <- dataset[[1]]
#' test_data <- do.call(rbind, dataset[setdiff(1:length(dataset),1)])
#' save(dataset, file="dataset.Rdata")
#' @export
create_dataset <- function(SNPdatafilter,numbercv=5){   #Dataset creation, test and train.
SNPdatafilter$Class <- as.factor(SNPdatafilter$Class)
total <- dim(SNPdatafilter)[1]
size <- ceiling(total/numbercv)
dataset<-as.list(numeric(numbercv))
n <- 1
set.seed(123456)
set_r <- sample(1:total,total)
for (i in 1:numbercv){
	set_n <- set_r[n:as.integer(size*i)]
	set_n <- set_n[!is.na(set_n)]
	dataset[[i]] <- SNPdatafilter[set_n,]
	n=n+size
}
return(dataset)
}
