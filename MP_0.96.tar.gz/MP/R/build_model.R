#' Filtering high correlation features.
#'
#' @param SNPdata SNP dataset loaded from a file. The first column is SNP name list. The last column is the status of SNP (Did it have identified as a risk SNP? Set "1" when the answer is "yes".) The colname of last column MUST be "status".
#' @param Correlation input the coefficient correlation, default is 0.70.
#' @return SNP dataset without high correlation feature.
#' @examples
#' SNPdatafilter <- filter_features(SNPdata)
#' save(SNPdatafilter, file='SNPdatafilter.Rdata')
#' @export
filter_features<-function(SNPdata, correlation=0.70){   #Correlation calculation, and hight correlation filtering.
	rownames(SNPdata)<-SNPdata[,1]
	status<-SNPdata[,length(colnames(SNPdata))]
    SNPdata<-SNPdata[,c(-length(colnames(SNPdata)),-1)]
    SNPdata_scale<-scale(SNPdata, center=T, scale=T)
	cor_SNPdata<-cor(SNPdata_scale)
	cor_SNPdata[is.na(cor_SNPdata)]<-0
	highlyCor<-caret::findCorrelation(cor_SNPdata, correlation)  #Correlation calculation.
	fea_filter_scale<-SNPdata_scale[,-highlyCor]         #Remove high correlation.
	fea_filter_scale<-as.data.frame(cbind(fea_filter_scale, status))
	fea_filter_scale[is.na(fea_filter_scale)]<-0
	return(fea_filter_scale)
}


#' Devide dataset into train dataset and test dataset.
#'
#' @param SNPdatafilter input a SNP data after filter high correlation feature. 
#' @param numbercv cross-validation number.
#' @return Train dataset and test dataset in a list.
#' @examples
#' dataset <- create_dataset(SNPdatafilter)
#' train_data <- dataset[[1]]
#' test_data <- dataset[[2]]
#' save(dataset, file="dataset.Rdata")
#' @export
create_dataset<-function(SNPdatafilter,numbercv=5){   #Dataset creation, test and train.
SNPdatafilter$status<-as.factor(SNPdatafilter$status)
set.seed(123456)
train_data<-SNPdatafilter[sample(1:dim(SNPdatafilter)[1],dim(SNPdatafilter)[1]*((numbercv-1)/numbercv)),]
test_data<-SNPdatafilter[setdiff(1:dim(SNPdatafilter)[1],sample(1:dim(SNPdatafilter)[1],dim(SNPdatafilter)[1]*((numbercv-1)/numbercv))),]
return(list(train_data=train_data,test_data=test_data))
}


#' Train a model with all of input feature.
#'
#' @param SNPdatafilter input a SNP data after filter high correlation feature.
#' @param train_data train dataset from fuction 'create_dataset'.
#' @param method input model type.
#' @param numbercv number of cross-validation.
#' @return Model training by train dataset and all feature.
#' @examples
#' model <- model_train(SNPdatafilter, train_data, method="rf", numbercv = 5)
#' save(model, file='model.Rdata')
#' @import parallel
#' @import doParallel
#' @export
model_train<-function(SNPdatafilter,train_data,method="rf", numbercv = 5, cores = 30){  #Model training.
	train_control<-caret::trainControl(method='cv',number=numbercv)
	MET=method
	c1 <- parallel::makeCluster(cores);
	doParallel::registerDoParallel(c1)
	message("Model training, please wait...")
	message("Attention: This step may takes several hours changing with your device. It takes about five hours on our platforms.")
	timestart <- Sys.time()
	model <- caret::train(status~.,data=train_data,trControl=train_control,method=MET)
	timeend <- Sys.time()
	runningtime<-timeend-timestart
	print(runningtime)
	#message(paste0("Running time:",runningtime))
	parallel::stopCluster(c1)


	return(model)
}


#' Evaluated a model.
#'
#' @param model input a model from fuction "model_train".
#' @param test_data input a test dataset from "create_dataset".
#' @return Prediction results, confusion matrix, F1 score and feature importance.
#' @examples
#' evaluate_data <- model_evaluate(model, test_data)
#' prediction_results <- model_evl[[1]]
#' confusion_matrix <- model_evl[[2]]
#' F1_score <- model_evl[[3]]
#' feature_importance <- model_evl[[4]]
#' @export
model_evaluate<-function(model, test_data){  #Model evaluation.
	predictions<-stats::predict(model, test_data)
	confusionmatrix<-caret::confusionMatrix(predictions, test_data$status, positive="0")
	precision <- caret::posPredValue(predictions, test_data$status, positive="0")
	recall <- caret::sensitivity(predictions, test_data$status, positive="0")
	F1 <- (2 * precision * recall) / (precision + recall) 
	imp <- caret::varImp(model,scale=TRUE)
	return(list(predictions=predictions,confusion_matrix=confusionmatrix,F1_score=F1,feature_importance=imp))
}
