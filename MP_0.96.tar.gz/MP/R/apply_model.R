#' Select model working best.
#'
#' @param SNPdatafilter input a SNP data after filter high correlation feature.
#' @param evaluate_data results from function 'model_evaluate'.
#' @param from the minimum top several feature you want to test in model.
#' @param to the maximum top  several feature you want to test in model.
#' @param sep integer, number of feature to skip.
#' @param method input model type.
#' @param numbercv number of cross-validation.
#' @return The best working model, with the most important feature.
#' @examples
#' model_best<-select_features(SNPdatafilter,evaluate_data,from=5,to=400,sep=20)
#' save(model_best,'model_best.Rdata')
#' @export
select_features <- function(SNPdatafilter,evaluate_data,from=5,to=length(feature_list),sep=5,method="rf", numbercv = 5){  #Feature and model selection.
	n<-1
	feature_list <- evaluate_data[4]$feature_importance$importance$Overall
	names(feature_list) <- rownames(evaluate_data[4]$feature_importance$importance)
	message("Loding feature importance...")
	#feature_list[order(-feature_list)]
	#seq(from=1,to=length(feature_list),by=1)
	model_set <- list()
	feature_evaluate_set <- list()
	top_feature_set <- list()
	evaluate_set <- c()
	for (i in seq(from=from,to=to,by=sep)){
	#seq(from=5,to=length(feature_list),by=1)
		top_feature <- names(feature_list[order(-feature_list)][1:i])
		top_feature_set[[n]] <- top_feature
		message("Selecting important features...")
		feature_dataset <- SNPdatafilter[,top_feature]
		status <- SNPdatafilter[,"status"]
		feature_dataset <- as.data.frame(cbind(feature_dataset,status))
		train_data <- create_dataset(feature_dataset,numbercv=numbercv)[[1]]
		test_data <- create_dataset(feature_dataset,numbercv=numbercv)[[2]]
		message("Generating datasets...")
		MET=method
		feature_model <- model_train(feature_dataset,train_data,method=MET)
		model_set[[n]] <- feature_model
		feature_evaluate <- model_evaluate(feature_model,test_data)
		feature_evaluate_set[[n]] <- feature_evaluate
		evaluate_set[n] <- feature_evaluate[[3]]
		n<-n+1
	}
		m_set<-order(-evaluate_set)[1]
		return(list(model_best <- model_set[[m_set]], confusion_matrix=feature_evaluate_set[[m_set]][[2]],F1_score=feature_evaluate_set[[m_set]][[3]],feature_names=top_feature_set[[m_set]]))
		#return(evaluate_set)
		

}


#' Get the predictive risk SNPs
#'
#' @param Model_best input results from fuction "select_features".
#' @param Dataset SNP data with features.
#' @return Model training by train dataset and all feature.
#' @examples
#' prediction <- SNP_predict(model_best, dataset, method="rf", numbercv = 5)
#' save(model, file='model.Rdata')
#' @export
SNP_predict <- function(model_best, dataset){
	model<-model_best[[1]]
	rownames(dataset) <- dataset[, 1]
	dataset <- dataset[, -1]
	predictions <- stats::predict(model, dataset)
	names(predictions) <- rownames(dataset)
	return(predictions)
}

