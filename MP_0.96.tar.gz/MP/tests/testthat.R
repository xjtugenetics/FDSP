library(testthat)
library(MP)
  
test_check("SNPprediction")
